#define DIS_DOT     0x20
#define DIS_BLACK   0x10
#define DIS_        0x11

void DisplayScan(void);


