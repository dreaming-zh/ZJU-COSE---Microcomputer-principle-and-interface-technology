#ifndef __SERIAL_H__
#define __SERIAL_H__

void Uart_Init(u16 brt);
s8 putchar(s8 ch);
s8 _getkey(void);
bit RXready(void);

#endif