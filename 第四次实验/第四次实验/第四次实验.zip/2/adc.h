/*************  adc.h    **************/
void ADC_Init();
u16 get_temperature(u16 adc);
u16 Get_ADC10bitResult(u8 channel); //channel = 0~8,8Ϊ�ڲ�BGV